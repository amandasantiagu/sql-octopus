create table _prisma_migrations
(
    id                  varchar(36)                               not null
        primary key,
    checksum            varchar(64)                               not null,
    finished_at         datetime(3)                               null,
    migration_name      varchar(255)                              not null,
    logs                text                                      null,
    rolled_back_at      datetime(3)                               null,
    started_at          datetime(3)  default CURRENT_TIMESTAMP(3) not null,
    applied_steps_count int unsigned default '0'                  not null
)
    collate = utf8mb4_unicode_ci;

INSERT INTO octopus._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) VALUES ('470220b4-3825-4465-a65c-f23c81d4e6b1', '64af8d5ef8f39d56ca3badfa16bb05b3173929cf5a431f161a3e6843ff07a7eb', '2025-06-12 20:11:10.609', '20250603081458_create_exercises_structure', null, null, '2025-06-12 20:11:10.041', 1);
INSERT INTO octopus._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) VALUES ('774c6c27-0803-4459-b1d0-9465ec339646', '8c6a9a5d11317f2967fe7871aae94b2e55fc21422f2903cfce5144a06e96a060', '2025-06-12 20:11:11.455', '20250612190942_add_json_to_answer', null, null, '2025-06-12 20:11:11.243', 1);
INSERT INTO octopus._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) VALUES ('7ae8a1d2-1515-47e6-b249-50c9348b25e1', 'f0095d887ba560451b2de2afc3b4f7ff30bbbb4faeafeee8d1d33727b6731b40', '2025-06-12 20:11:15.086', '20250612201113_update_answer_type', null, null, '2025-06-12 20:11:14.992', 1);
INSERT INTO octopus._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) VALUES ('80ce2536-dd0c-4091-98fd-6d262a4a6e54', '4f7e7442bdb288c403765b8aec99af8fa193bb35f9633e20f143767d5b5f241f', '2025-06-12 20:11:10.035', '20250521073803_add_column_last_life_lost_at_user_table', null, null, '2025-06-12 20:11:09.937', 1);
INSERT INTO octopus._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) VALUES ('b64e69a5-5692-4262-9753-4c9c3717c33d', 'f26d3a78c41b42ffd87237fd0aed6541535eeb5894904c71df4a011a7c9d3e0b', '2025-06-12 20:11:11.057', '20250611173201_update_blanks_to_json', null, null, '2025-06-12 20:11:10.952', 1);
INSERT INTO octopus._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) VALUES ('ed2c4bc7-b9db-4685-821d-cbf5fe584d87', '31ca5d42612e2f2baa7b18f59b08f76d7e0d8f30548659c22fff397f9700a512', '2025-06-12 20:11:09.813', '20250327082634_init', null, null, '2025-06-12 20:11:09.755', 1);
INSERT INTO octopus._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) VALUES ('f41d9cb5-f3a5-4d1b-8060-11da1bd6b422', 'cdebbea143079e20ced16cf891a9e48933da54a164275169fa8c8f3cbad96371', '2025-06-12 20:11:09.930', '20250429081304_user_create_table', null, null, '2025-06-12 20:11:09.823', 1);
INSERT INTO octopus._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) VALUES ('f748a0c2-51b9-407e-b78c-3d0e2af5e229', '03df84eb797e2aa830e10880db4139fdd2f5c2867637d420df00746929133d51', '2025-06-12 20:11:10.944', '20250611075542_user_progress', null, null, '2025-06-12 20:11:10.616', 1);
INSERT INTO octopus._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) VALUES ('ffd62b3a-3ae3-4377-91e2-35bef21551a3', '42c7a2485643c90770021cd3c516af4d5279f8fe181b1b96756fcd0b8e02401c', '2025-06-12 20:11:11.237', '20250612134100_add_exp_to_user_progress', null, null, '2025-06-12 20:11:11.063', 1);
