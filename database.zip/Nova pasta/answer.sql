create table answer
(
    id         varchar(191)                             not null
        primary key,
    userId     varchar(191)                             not null,
    exerciseId varchar(191)                             not null,
    answer     json                                     not null,
    created_at datetime(3) default CURRENT_TIMESTAMP(3) not null,
    updated_at datetime(3) default CURRENT_TIMESTAMP(3) not null,
    deleted_at datetime(3)                              null,
    constraint answer_exerciseId_fkey
        foreign key (exerciseId) references exercise (id)
            on update cascade,
    constraint answer_userId_fkey
        foreign key (userId) references user (id)
            on update cascade
)
    collate = utf8mb4_unicode_ci;

INSERT INTO octopus.answer (id, userId, exerciseId, answer, created_at, updated_at, deleted_at) VALUES ('cmbvbwgn60003n08s2llc0kuj', 'cmbttokin0000qa0vlfwkjy5x', 'cmbttrc6s0007qa0vp8k5ciuc', '"SELECT sapo, verde FROM azul;"', '2025-06-13 21:37:37.603', '2025-06-13 21:42:04.596', null);
INSERT INTO octopus.answer (id, userId, exerciseId, answer, created_at, updated_at, deleted_at) VALUES ('cmbvbwgnk0005n08sxde1yjbb', 'cmbttokin0000qa0vlfwkjy5x', 'cmbttro9t0009qa0v13pw7q09', '"Verdadeiro"', '2025-06-13 21:37:37.617', '2025-06-13 21:42:04.607', null);
INSERT INTO octopus.answer (id, userId, exerciseId, answer, created_at, updated_at, deleted_at) VALUES ('cmbvbwgob0007n08s45ma2brd', 'cmbttokin0000qa0vlfwkjy5x', 'cmbtts6jh000bqa0v5ujvl4a1', '"select"', '2025-06-13 21:37:37.644', '2025-06-13 21:42:04.618', null);
INSERT INTO octopus.answer (id, userId, exerciseId, answer, created_at, updated_at, deleted_at) VALUES ('cmbvbwgoq0009n08sfp2z7vb4', 'cmbttokin0000qa0vlfwkjy5x', 'cmbttwfzf000fqa0vloywpnbb', '[{"label": "select", "value": "Escolhe as colunas a serem exibidas no resultado da consulta."}, {"label": "where", "value": "Filtra registros com base em condições específicas."}, {"label": "from", "value": "Define a tabela de onde os dados serão recuperados."}, {"label": "distinct", "value": "Remove valores duplicados do resultado."}]', '2025-06-13 21:37:37.658', '2025-06-13 21:42:04.638', null);
