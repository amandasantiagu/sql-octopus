create table content
(
    id           varchar(191)                             not null
        primary key,
    label        varchar(120)                             not null,
    moduleId     varchar(191)                             not null,
    completed_at datetime(3)                              null,
    created_at   datetime(3) default CURRENT_TIMESTAMP(3) not null,
    updated_at   datetime(3) default CURRENT_TIMESTAMP(3) not null,
    deleted_at   datetime(3)                              null,
    constraint content_moduleId_fkey
        foreign key (moduleId) references module (id)
            on update cascade
)
    collate = utf8mb4_unicode_ci;

INSERT INTO octopus.content (id, label, moduleId, completed_at, created_at, updated_at, deleted_at) VALUES ('cmbttqarb0003qa0vp3ahewo2', 'Selecionando dados', 'cmbttpdpa0001qa0vbzdw74w1', null, '2025-06-12 20:21:10.776', '2025-06-12 20:21:10.776', null);
INSERT INTO octopus.content (id, label, moduleId, completed_at, created_at, updated_at, deleted_at) VALUES ('cmbttqhpa0005qa0v3m7iq029', 'Filtrando dados', 'cmbttpdpa0001qa0vbzdw74w1', null, '2025-06-12 20:21:19.774', '2025-06-12 20:21:19.774', null);
INSERT INTO octopus.content (id, label, moduleId, completed_at, created_at, updated_at, deleted_at) VALUES ('cmbvf5v3a0001n0dortocituh', 'Ordenando dados', 'cmbttpdpa0001qa0vbzdw74w1', null, '2025-06-13 23:08:55.078', '2025-06-13 23:08:55.078', null);
INSERT INTO octopus.content (id, label, moduleId, completed_at, created_at, updated_at, deleted_at) VALUES ('cmbvf622o0003n0dopcvod6a8', 'Unindo dados', 'cmbttpdpa0001qa0vbzdw74w1', null, '2025-06-13 23:09:04.129', '2025-06-13 23:09:04.129', null);
INSERT INTO octopus.content (id, label, moduleId, completed_at, created_at, updated_at, deleted_at) VALUES ('cmbwkpwo90002nv23hcf49ho7', 'Junção não natural', 'cmbwkol730000nv23juhj3eaw', null, '2025-06-14 18:32:14.506', '2025-06-14 18:32:14.506', null);
INSERT INTO octopus.content (id, label, moduleId, completed_at, created_at, updated_at, deleted_at) VALUES ('cmbwkq6j50004nv23tf8exavq', 'Junção natural', 'cmbwkol730000nv23juhj3eaw', null, '2025-06-14 18:32:27.281', '2025-06-14 18:32:27.281', null);
INSERT INTO octopus.content (id, label, moduleId, completed_at, created_at, updated_at, deleted_at) VALUES ('cmbwkqjzd0006nv23whmx0os9', 'Junção externa', 'cmbwkol730000nv23juhj3eaw', null, '2025-06-14 18:32:44.714', '2025-06-14 18:32:44.714', null);
INSERT INTO octopus.content (id, label, moduleId, completed_at, created_at, updated_at, deleted_at) VALUES ('cmbwlio2e001dnv231wtsihlq', 'Subconsultas not in', 'cmbwli8p7001bnv23kqlpguns', null, '2025-06-14 18:54:36.374', '2025-06-14 18:54:36.374', null);
INSERT INTO octopus.content (id, label, moduleId, completed_at, created_at, updated_at, deleted_at) VALUES ('cmbwlixd7001fnv23nfi8vlp3', 'Subconsultas some', 'cmbwli8p7001bnv23kqlpguns', null, '2025-06-14 18:54:48.428', '2025-06-14 18:54:48.428', null);
INSERT INTO octopus.content (id, label, moduleId, completed_at, created_at, updated_at, deleted_at) VALUES ('cmbwlj2ct001hnv239hpp99wl', 'Subconsultas all', 'cmbwli8p7001bnv23kqlpguns', null, '2025-06-14 18:54:54.894', '2025-06-14 18:54:54.894', null);
INSERT INTO octopus.content (id, label, moduleId, completed_at, created_at, updated_at, deleted_at) VALUES ('cmbwlj9by001jnv23xuu9g71g', 'Subconsultas exists', 'cmbwli8p7001bnv23kqlpguns', null, '2025-06-14 18:55:03.934', '2025-06-14 18:55:03.934', null);
INSERT INTO octopus.content (id, label, moduleId, completed_at, created_at, updated_at, deleted_at) VALUES ('cmbwljobx001lnv23rk4qbf8r', 'Subconsultas update', 'cmbwli8p7001bnv23kqlpguns', null, '2025-06-14 18:55:23.373', '2025-06-14 18:55:23.373', null);
INSERT INTO octopus.content (id, label, moduleId, completed_at, created_at, updated_at, deleted_at) VALUES ('cmbwlkz8v001onv23bgc6j20r', 'Restrições', 'cmbwlkhja001mnv23mjvqoi7b', null, '2025-06-14 18:56:24.175', '2025-06-14 18:56:24.175', null);
INSERT INTO octopus.content (id, label, moduleId, completed_at, created_at, updated_at, deleted_at) VALUES ('cmbwlladd001qnv231q4qya5c', 'Introdução a visões', 'cmbwlkhja001mnv23mjvqoi7b', null, '2025-06-14 18:56:38.593', '2025-06-14 18:56:38.593', null);
INSERT INTO octopus.content (id, label, moduleId, completed_at, created_at, updated_at, deleted_at) VALUES ('cmbwllkei001snv23o4nj3od0', 'Introdução a visões revoke', 'cmbwlkhja001mnv23mjvqoi7b', null, '2025-06-14 18:56:51.595', '2025-06-14 18:56:51.595', null);
