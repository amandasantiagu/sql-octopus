create table module
(
    id         varchar(191)                             not null
        primary key,
    label      varchar(120)                             not null,
    created_at datetime(3) default CURRENT_TIMESTAMP(3) not null,
    updated_at datetime(3) default CURRENT_TIMESTAMP(3) not null,
    deleted_at datetime(3)                              null
)
    collate = utf8mb4_unicode_ci;

INSERT INTO octopus.module (id, label, created_at, updated_at, deleted_at) VALUES ('cmbttpdpa0001qa0vbzdw74w1', 'Módulo I', '2025-06-12 20:20:27.934', '2025-06-12 20:20:27.934', null);
INSERT INTO octopus.module (id, label, created_at, updated_at, deleted_at) VALUES ('cmbwkol730000nv23juhj3eaw', 'Módulo II', '2025-06-14 18:31:12.976', '2025-06-14 18:31:12.976', null);
INSERT INTO octopus.module (id, label, created_at, updated_at, deleted_at) VALUES ('cmbwli8p7001bnv23kqlpguns', 'Módulo III', '2025-06-14 18:54:16.459', '2025-06-14 18:54:16.459', null);
INSERT INTO octopus.module (id, label, created_at, updated_at, deleted_at) VALUES ('cmbwlkhja001mnv23mjvqoi7b', 'Módulo IV', '2025-06-14 18:56:01.222', '2025-06-14 18:56:01.222', null);
