create table user
(
    id                    varchar(191)                             not null
        primary key,
    name                  varchar(191)                             not null,
    email                 varchar(191)                             not null,
    password              varchar(191)                             not null,
    already_done_tutorial tinyint(1)  default 0                    not null,
    created_at            datetime(3) default CURRENT_TIMESTAMP(3) not null,
    exp                   int         default 0                    not null,
    life                  int         default 3                    not null,
    updated_at            datetime(3) default CURRENT_TIMESTAMP(3) not null,
    last_life_lost_at     datetime(3)                              null,
    constraint user_email_key
        unique (email)
)
    collate = utf8mb4_unicode_ci;

INSERT INTO octopus.user (id, name, email, password, already_done_tutorial, created_at, exp, life, updated_at, last_life_lost_at) VALUES ('cmbttokin0000qa0vlfwkjy5x', 'amanda santiago', 'amndsantiagu@gmail.com', '$2b$10$PuvR6H1oBl8TNeiLbV6fM.UO7rDq664l8xFc/1ikW7gjMPbwkrCMW', 1, '2025-06-12 20:19:50.112', 1400, 3, '2025-06-13 22:55:21.186', '2025-06-13 21:30:54.904');
INSERT INTO octopus.user (id, name, email, password, already_done_tutorial, created_at, exp, life, updated_at, last_life_lost_at) VALUES ('cmbtytmjb0000qa63oinmdic2', 'maria julia silvia oliveira', 'maria@gmail.com', '$2b$10$5bBWuW6NuyacbE4f9yrHPePecVfQl6vLzvw/XRMlSMOuYNRAFiO2q', 1, '2025-06-12 22:43:44.087', 150, 2, '2025-06-13 15:11:04.712', null);
INSERT INTO octopus.user (id, name, email, password, already_done_tutorial, created_at, exp, life, updated_at, last_life_lost_at) VALUES ('cmbu3h12c0000qah4c65lxdb4', 'julia', 'julia@gmail.com', '$2b$10$4N9qwxzSYhdMynmuIkOvaejNcOd4GHVNo3j51364YlvKS1Za1cbl6', 1, '2025-06-13 00:53:54.468', 0, 3, '2025-06-13 00:54:28.066', null);
