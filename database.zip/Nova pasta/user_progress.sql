create table user_progress
(
    id           varchar(191)                             not null
        primary key,
    userId       varchar(191)                             not null,
    contentId    varchar(191)                             not null,
    duration     int                                      null,
    hits         int                                      null,
    completed_at datetime(3)                              null,
    created_at   datetime(3) default CURRENT_TIMESTAMP(3) not null,
    updated_at   datetime(3) default CURRENT_TIMESTAMP(3) not null,
    deleted_at   datetime(3)                              null,
    exp          int                                      null,
    constraint user_progress_contentId_fkey
        foreign key (contentId) references content (id)
            on update cascade,
    constraint user_progress_userId_fkey
        foreign key (userId) references user (id)
            on update cascade
)
    collate = utf8mb4_unicode_ci;

INSERT INTO octopus.user_progress (id, userId, contentId, duration, hits, completed_at, created_at, updated_at, deleted_at, exp) VALUES ('cmbvbwgmf0001n08s0e9ninx5', 'cmbttokin0000qa0vlfwkjy5x', 'cmbttqarb0003qa0vp3ahewo2', 22, 75, null, '2025-06-13 21:37:37.575', '2025-06-13 21:42:04.573', null, 150);
